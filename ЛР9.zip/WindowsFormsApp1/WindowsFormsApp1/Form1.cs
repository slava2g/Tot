﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static WindowsFormsApp1.Program;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
        private void button1_Click_1(object sender, EventArgs e)
        {
            CarItem car = new CarItem("Легковий автомобіль 1");
            car.components.Add(new CarPart("Двигун"));
            car.components.Add(new CarPart("Кузов"));

            richTextBox1.Text = "Автомобіль з основними частинами:\n";
            richTextBox1.Text += car.GetDesc();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CarItem car = new CarItem("Легковий автомобіль 2");
            car.components.Add(new CarPart("Кузов"));
            car.components.Add(new CarPart("Колеса"));

            richTextBox1.Text = "Автомобіль з кузовом та колесами:\n";
            richTextBox1.Text += car.GetDesc();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CarItem car = new CarItem("Легковий автомобіль 3");
            car.components.Add(new CarPart("Кузов"));
            car.components.Add(new CarPart("Трансмісія"));

            richTextBox1.Text = "Автомобіль з Кузов та трансмісією:\n";
            richTextBox1.Text += car.GetDesc();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CarItem car1 = new CarItem("Легковий автомобіль1");
            car1.components.Add(new CarPart("Двигун"));
            car1.components.Add(new CarPart("Кузов"));

            CarItem car2 = new CarItem("Легковий автомобіль2");
            car2.components.Add(new CarPart("Колеса"));
            car2.components.Add(new CarPart("Гальмівна система"));

            CarItem fullCar = new CarItem("Повний комплект");
            fullCar.components.Add(new CarPart("Двигун"));
            fullCar.components.Add(new CarPart("Трансмісія"));
            fullCar.components.Add(car1);
            fullCar.components.Add(car2);

            richTextBox1.Text = car1.GetDesc() + "\n";
            richTextBox1.Text += fullCar.GetDesc();

        }
    }
}
