﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
        public abstract class CarComponent
        {
            protected string desc;
            public CarComponent() { }
            public CarComponent(string d) { desc = d; }
            public abstract string GetDesc();
        }

        // Окремі частини автомобіля (наприклад, двигун, кузов, колеса)
        public class CarPart : CarComponent
        {
            public CarPart(string d) : base(d) { }
            public override string GetDesc()
            {
                return desc;
            }
        }

        // Автомобіль, який складається з різних компонентів
        public class CarItem : CarComponent
        {
            public List<CarComponent> components = new List<CarComponent>();

            public CarItem(string d) : base(d) { }

            public override string GetDesc()
            {
                string tmp = desc;
                foreach (CarComponent c in components)
                {
                    tmp = tmp + " - " + c.GetDesc();
                }
                return tmp;
            }
        }
    }
}
