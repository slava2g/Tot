﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp35
{
    abstract public class Builder
    {

        public abstract void createRoses();
        public abstract void createTulips();
        public abstract void createChamomiles();
        public abstract void createOrchids();
        public abstract void createWhiteRoses();

        public abstract Product getResult();
    }
}
