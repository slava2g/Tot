﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp35
{
    public abstract class Product
    {
        public string Roses;
        public string Tulips;
        public string Chamomiles;
        public string Orchids;
        public string WhiteRoses;

        public Product()
        {
        }
        public Product(Product p) 
        { 
            Roses = p.Roses;    
            Tulips = p.Tulips;
            Chamomiles = p.Chamomiles;
            Orchids = p.Orchids;
            WhiteRoses = p.WhiteRoses;
        }

        abstract public Product clone();
      public string Tostring()
        {
            return "Roses="+Roses+ ", Tulips="+Tulips+ ", Chamomiles=" + Chamomiles + ", Orchids= "+Orchids+", White Roses=" + WhiteRoses ;
        }
    }
    
}
