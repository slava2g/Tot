﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp35
{
    public class BuilderB2:Builder
    {
        private Product p;
        void reset()
        {
            p = new Product2();
        }

        public override void createRoses()

        {
            p.Roses = "0";
        }

        public override void createChamomiles()
        {
            p.Chamomiles = "6";
        }
        public override void createTulips()
        {
            p.Tulips = "7";
        }
        public override void createOrchids()
        {
            p.Orchids = "3";
        }
        public override void createWhiteRoses()
        {
            p.WhiteRoses = "0";
        }
        public override Product getResult()
        {
            reset();
            createRoses();
            createChamomiles();
            createTulips();
            createOrchids();
            createWhiteRoses();
            return p;
        }
    }
}
