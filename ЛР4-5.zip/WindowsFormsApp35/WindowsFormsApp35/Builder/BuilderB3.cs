﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp35
{
    public class BuilderB3: Builder
    {
        private Product p;
        void reset()
        {
            p = new Product3();
        }

        public override void createRoses()

        {
            p.Roses = "8";
        }

        public override void createChamomiles()
        {
            p.Chamomiles = "3";
        }
        public override void createTulips()
        {
            p.Tulips = "5";
        }
        public override void createOrchids()
        {
            p.Orchids = "2";
        }
        public override void createWhiteRoses()
        {
            p.WhiteRoses = "12";
        }
        public override Product getResult()
        {
            reset();
            createRoses();
            createChamomiles();
            createTulips();
            createOrchids();
            createWhiteRoses();
            return p;
        }
    }
}
