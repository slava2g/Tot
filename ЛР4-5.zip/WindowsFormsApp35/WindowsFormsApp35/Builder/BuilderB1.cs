﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp35
{
    public class BuilderB1:Builder
    {
        private Product p;
        void reset()
        { 
        p = new Product1();  
        }

        public override void createRoses()
        
        {
            p.Roses = "3";
        }

        public override void createChamomiles() 
        {
            p.Chamomiles = "0";
        }
        public override void createTulips() 
        {
            p.Tulips = "0";
        }
        public override void createOrchids() 
        {
            p.Orchids = "2";
        }
        public override void createWhiteRoses()
        {
            p.WhiteRoses = "2";
        }

        public override Product getResult()
        {
            reset();
            createRoses();
            createChamomiles();
            createTulips();
            createOrchids();
            createWhiteRoses();
            return p;
        }

    }
}
