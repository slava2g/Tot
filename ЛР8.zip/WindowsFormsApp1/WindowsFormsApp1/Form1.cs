﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
              
        }
        abstract class Airplane
        {
            public string Name { get; protected set; }
            public abstract int GetCost();
            public abstract int GetSpeed();
            public abstract int GetWeight();
        }

        class RegularAirplane : Airplane
        {
            public RegularAirplane()
            {
                Name = "Звичайний літак";
            }

            public override int GetCost()
            {
                return 500;
            }

            public override int GetSpeed()
            {
                return 600; 
            }

            public override int GetWeight()
            {
                return 10000; 
            }
        }

        abstract class AirplaneDecorator : Airplane
        {
            protected Airplane airplane;

            public AirplaneDecorator(Airplane airplane)
            {
                this.airplane = airplane;
            }

            public override int GetCost()
            {
                return airplane.GetCost();
            }

            public override int GetSpeed()
            {
                return airplane.GetSpeed();
            }

            public override int GetWeight()
            {
                return airplane.GetWeight();
            }
        }

        class ExtraEngine : AirplaneDecorator
        {
            public ExtraEngine(Airplane airplane) : base(airplane)
            {
                Name = airplane.Name + ", з додатковим двигуном";
            }

            public override int GetCost()
            {
                return airplane.GetCost() + 200;
            }

            public override int GetSpeed()
            {
                return airplane.GetSpeed() + 100; 
            }

            public override int GetWeight()
            {
                return airplane.GetWeight() + 500; 
            }
        }

        class LuxurySeats : AirplaneDecorator
        {
            public LuxurySeats(Airplane airplane) : base(airplane)
            {
                Name = airplane.Name + ", з люксовими сидіннями";
            }

            public override int GetCost()
            {
                return airplane.GetCost() + 100;
            }

            public override int GetSpeed()
            {
                return airplane.GetSpeed(); 
            }

            public override int GetWeight()
            {
                return airplane.GetWeight() + 200; 
            }
        }

        class Aerodynamics : AirplaneDecorator
        {
            public Aerodynamics(Airplane airplane) : base(airplane)
            {
                Name = airplane.Name + ", з поліпшеною аеродинамікою";
            }

            public override int GetCost()
            {
                return airplane.GetCost() + 150;
            }

            public override int GetSpeed()
            {
                return airplane.GetSpeed() + 50; 
            }

            public override int GetWeight()
            {
                return airplane.GetWeight(); 
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Airplane airplane1 = new RegularAirplane();
            airplane1 = new ExtraEngine(airplane1);
            label1.Text = ("Название: " + airplane1.Name);
            label2.Text = ("Ціна:" + airplane1.GetCost());
            label3.Text = ("Швидкість: " + airplane1.GetSpeed() + " км/ч");
            label4.Text = ("Вага:" + airplane1.GetWeight() + " кг");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Airplane airplane2 = new RegularAirplane();
            airplane2 = new LuxurySeats(airplane2);
            label1.Text = ("Название: " + airplane2.Name);
            label2.Text = ("Ціна: " + airplane2.GetCost());
            label3.Text = ("Швидкість: " + airplane2.GetSpeed() + " км/ч");
            label4.Text = ("Вага:" + airplane2.GetWeight() + " кг");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Airplane airplane3 = new RegularAirplane();
            airplane3 = new ExtraEngine(airplane3);
            airplane3 = new LuxurySeats(airplane3);
            label1.Text = ("Название: " + airplane3.Name);
            label2.Text = ("Ціна: " + airplane3.GetCost());
            label3.Text = ("Швидкість: " + airplane3.GetSpeed() + " км/ч");
            label4.Text = ("Вага: " + airplane3.GetWeight() + " кг");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Airplane airplane4 = new RegularAirplane();
            airplane4 = new ExtraEngine(airplane4);
            airplane4 = new LuxurySeats(airplane4);
            airplane4 = new Aerodynamics(airplane4);
            label1.Text = ("Название: " + airplane4.Name);
            label2.Text = ("Ціна: " + airplane4.GetCost());
            label3.Text = ("Швидкість: " + airplane4.GetSpeed() + " км/ч");
            label4.Text = ("Вага: " + airplane4.GetWeight() + " кг");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Airplane airplane5 = new RegularAirplane();
            airplane5 = new Aerodynamics(airplane5);
            label1.Text = ("Назва: " + airplane5.Name);
            label2.Text = ("Ціна: " + airplane5.GetCost());
            label3.Text = ("Швидкість: " + airplane5.GetSpeed() + " км/год");
            label4.Text = ("Вага: " + airplane5.GetWeight() + " кг");
        }
    }
}
