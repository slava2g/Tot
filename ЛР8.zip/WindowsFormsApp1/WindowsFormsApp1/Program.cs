﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }

        abstract class Airplane
        {
            public string Name { get; protected set; }
            public abstract int GetCost();
            public abstract int GetSpeed();
            public abstract int GetWeight();
        }

        class RegularAirplane : Airplane
        {
            public RegularAirplane()
            {
                Name = "Звичайний літак";
            }

            public override int GetCost()
            {
                return 500;
            }

            public override int GetSpeed()
            {
                return 600; 
            }

            public override int GetWeight()
            {
                return 10000; 
            }
        }

        abstract class AirplaneDecorator : Airplane
        {
            protected Airplane airplane;

            public AirplaneDecorator(Airplane airplane)
            {
                this.airplane = airplane;
            }

            public override int GetCost()
            {
                return airplane.GetCost();
            }

            public override int GetSpeed()
            {
                return airplane.GetSpeed();
            }

            public override int GetWeight()
            {
                return airplane.GetWeight();
            }
        }

     
        class ExtraEngine : AirplaneDecorator
        {
            public ExtraEngine(Airplane airplane) : base(airplane)
            {
                Name = airplane.Name + ", з додатковим двигуном";
            }

            public override int GetCost()
            {
                return airplane.GetCost() + 200;
            }

            public override int GetSpeed()
            {
                return airplane.GetSpeed() + 100; 
            }

            public override int GetWeight()
            {
                return airplane.GetWeight() + 500; 
            }
        }

        class LuxurySeats : AirplaneDecorator
        {
            public LuxurySeats(Airplane airplane) : base(airplane)
            {
                Name = airplane.Name + ", з люксовими сидіннями";
            }

            public override int GetCost()
            {
                return airplane.GetCost() + 100;
            }

            public override int GetSpeed()
            {
                return airplane.GetSpeed(); 
            }

            public override int GetWeight()
            {
                return airplane.GetWeight() + 200; 
            }
        }


        class Aerodynamics : AirplaneDecorator
        {
            public Aerodynamics(Airplane airplane) : base(airplane)
            {
                Name = airplane.Name + ", з поліпшеною аеродинамікою";
            }

            public override int GetCost()
            {
                return airplane.GetCost() + 150;
            }

            public override int GetSpeed()
            {
                return airplane.GetSpeed() + 50; 
            }

            public override int GetWeight()
            {
                return airplane.GetWeight(); 
            }
        }
       
    }
}
