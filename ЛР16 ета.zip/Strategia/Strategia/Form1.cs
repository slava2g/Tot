﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Strategia
{
    public partial class Form1 : Form
    {
        private ISortStrategy sortStrategy;
        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.Add("Bubble Sort");
            comboBox1.Items.Add("Quick Sort");
            comboBox1.Items.Add("Selection Sort");
            comboBox1.SelectedIndex = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int[] numbers = textBox1.Text.Split(new[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                                                 .Select(int.Parse)
                                                 .ToArray();

                switch (comboBox1.SelectedItem.ToString())
                {
                    case "Bubble Sort":
                        sortStrategy = new BubbleSort();
                        break;
                    case "Quick Sort":
                        sortStrategy = new QuickSort();
                        break;
                    case "Selection Sort":
                        sortStrategy = new SelectionSort();
                        break;
                }

                int[] sortedNumbers = sortStrategy.Sort(numbers);
                label1.Text = "Відсортовано: " + string.Join(", ", sortedNumbers);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка: " + ex.Message);
            }
        }
    }
    }

