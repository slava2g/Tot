﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstFactLibrary

{
    public abstract class AFact
    {
        public abstract Aequipment createEquipment();

        public abstract AtrainPlan createTrainPlan();

        public abstract Arunner createRunner();

       
    }
}
