﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstFactLibrary
{
    public class TrainPlan500:AtrainPlan
    {
        public TrainPlan500()
        {
            Name = "Training plan 500 metr";
        }
    }
}
