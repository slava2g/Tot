﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstFactLibrary
{
    public class Fact500metr:AFact
    {
        public override Aequipment createEquipment()
        {
            return new Equipment500();
        }

        public override Arunner createRunner()
        {
            return new Runner500();
        }

        public override AtrainPlan createTrainPlan()
        {
            return new TrainPlan500();
        }
    }
}
