﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstFactLibrary
{
    public class Equipment500:Aequipment
    {
        public Equipment500()
        {
            Name = "Equipment for 500 metr";
        }
    }
}
