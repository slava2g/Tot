﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstFactLibrary
{
    public class Fact200metr:AFact
    {
        

        public override Aequipment createEquipment()
            {
                 return new Equipment200();      
            }

        public override AtrainPlan createTrainPlan()
            {
                return new TrainPlan200();
            }

        public override Arunner createRunner()
            {
                 return new Runner200();
            }
        
    }
}
