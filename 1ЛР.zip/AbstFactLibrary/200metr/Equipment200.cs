﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstFactLibrary

{
    public class Equipment200:Aequipment
    {
        public Equipment200()
        {
            Name = "Equipment for 200 metr";
        }
    }
}
