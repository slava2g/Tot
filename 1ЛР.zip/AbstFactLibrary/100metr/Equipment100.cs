﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstFactLibrary
{
    public class Equipment100 : Aequipment
    {
        public Equipment100()
        {
            Name = "Equipment for 100 metr";
        }
    }
}
