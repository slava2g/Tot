﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstFactLibrary
{
    public class Fact100metr:AFact
    {
        public override Arunner createRunner()
        {
            return new Runner100();
        }

        public override Aequipment createEquipment()
        {
            return new Equipment100();
        }

        public override AtrainPlan createTrainPlan()
        {
            return new TrainPlan100();
        }
    }
}
