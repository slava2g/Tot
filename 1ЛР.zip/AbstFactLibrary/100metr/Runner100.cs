﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstFactLibrary
{
    public class Runner100 : Arunner
    {
        public Runner100()
        {
            Name = "Runner 100 metr";
        }
    }
}
