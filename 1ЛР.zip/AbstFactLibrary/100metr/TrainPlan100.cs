﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstFactLibrary
{
    public class TrainPlan100:AtrainPlan
    {
        public TrainPlan100()
        {
            Name = "Training plan 100 metr";
        }
    }
}
