﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Command
{
    public partial class Form1 : Form
    {
        private List<ICommand> commands = new List<ICommand>
        {
            new GetEcoTipsCommand(),
            new ViewInitiativesCommand(),
            new OpenEcoWebsiteCommand(),
            new ClimateFactsCommand()
        };
        public Form1()
        {
            InitializeComponent();
            CreateDynamicMenu();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void CreateDynamicMenu()
        {
            int yOffset = 20;
            foreach (var cmd in commands)
            {
                Button btn = new Button
                {
                    Text = cmd.GetInfo(),
                    Width = 250,
                    Height = 40,
                    Top = yOffset,
                    Left = 50
                };

                btn.Click += (sender, e) => cmd.Execute(new List<object>());
                Controls.Add(btn);
                yOffset += 50;
            }
        }
    }
}
