﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Command
{
    public class ClimateFactsCommand : ICommand
    {
        private static readonly string[] Facts =
        {
            "Клімат Землі стає теплішим: середня температура зросла на 1,1°C з 19 століття.",
            "Льодовики Арктики тануть у два рази швидше, ніж передбачалося.",
            "Рівень океану підвищився на 20 см за останні 100 років.",
            "70% парникових газів спричинені використанням викопного палива.",
            "Африка нагрівається в 1,5 рази швидше, ніж решта світу."
        };

        private static readonly Random random = new Random();

        public string GetInfo() => "Факти про зміну клімату";

        public void Execute(List<object> parameters)
        {
            int index = random.Next(Facts.Length);
            MessageBox.Show(Facts[index], "Факт про клімат", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
