﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command
{
    public class OpenEcoWebsiteCommand : ICommand
    {
        public string GetInfo() => "Відкрити екологічний сайт";

        public void Execute(List<object> parameters)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "https://wwf.panda.org/",
                UseShellExecute = true
            });
        }
    }
}
