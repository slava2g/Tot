﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Command
{
    public class GetEcoTipsCommand : ICommand
    {
        public string GetInfo() => "Отримати екологічні поради";

        public void Execute(List<object> parameters)
        {
            MessageBox.Show("Ось кілька екологічних порад:\n1. Економте воду\n2. Використовуйте менше пластику\n3. Сортуйте сміття",
                "Еко-Поради", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
