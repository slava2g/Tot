﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Command
{
    public class ViewInitiativesCommand : ICommand
    {
        public string GetInfo() => "Переглянути ініціативи";

        public void Execute(List<object> parameters)
        {
            MessageBox.Show("Перегляд екологічних ініціатив:\n- Озеленення міста\n- Чисті річки\n- Менше пластику",
                "Еко-Ініціативи", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
