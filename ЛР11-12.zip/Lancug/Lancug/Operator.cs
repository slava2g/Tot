﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lancug
{
    abstract class Operator
    {
        protected Operator nextOperator;

        public void SetNext(Operator nextOperator)
        {
            this.nextOperator = nextOperator;
        }

        public abstract void HandleRequest(string request, Form1 form);
    }
}
