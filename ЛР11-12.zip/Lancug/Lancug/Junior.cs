﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lancug
{
    class JuniorOperator : Operator
    {
        public override void HandleRequest(string request, Form1 form)
        {
            if (request.ToLower().Contains("загальна інформація"))
            {
                form.UpdateChat("Ось загальна інформація щодо вашого питання.", "Молодший оператор");
            }
            else if (nextOperator != null)
            {
                nextOperator.HandleRequest(request, form);
            }
        }
    }
}
