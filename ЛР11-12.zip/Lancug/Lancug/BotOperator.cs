﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lancug
{
    class BotOperator : Operator
    {
        public override void HandleRequest(string request, Form1 form)
        {
            if (request.ToLower().Contains("привіт") || request.ToLower().Contains("допомога"))
            {
                form.UpdateChat("Вітаю! Я ваш віртуальний помічник. Чим можу допомогти?", "Бот");
            }
            else if (nextOperator != null)
            {
                nextOperator.HandleRequest(request, form);
            }
        }
    }
}
