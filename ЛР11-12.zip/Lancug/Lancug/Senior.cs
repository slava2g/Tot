﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lancug
{
    class SeniorOperator : Operator
    {
        public override void HandleRequest(string request, Form1 form)
        {
            form.UpdateChat("Ваш запит потребує детального аналізу. Будь ласка, зачекайте...", "Старший оператор");
        }
    }
}
