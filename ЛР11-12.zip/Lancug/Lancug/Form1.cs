﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lancug
{
    public partial class Form1 : Form
    {
        private Operator botOperator;
        public Form1()
        {
            InitializeComponent();
            botOperator = new BotOperator();
            var junior = new JuniorOperator();
            var senior = new SeniorOperator();

            botOperator.SetNext(junior);
            junior.SetNext(senior);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userRequest = textBox1.Text.Trim();
            if (string.IsNullOrEmpty(userRequest)) return;

            richTextBox1.AppendText($"Користувач: {userRequest}\n");
            botOperator.HandleRequest(userRequest, this);
            textBox1.Clear();
        }

        public void UpdateChat(string message, string operatorName)
        {
            richTextBox1.AppendText($"{operatorName}: {message}\n");
            label1.Text = $"Відповідає: {operatorName}";
        }

    }
}
