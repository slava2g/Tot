﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject1
{
    public class WordBuilder
    {
        public bool CanFormWord(string sourceWord, string targetWord)
        {
            if (string.IsNullOrEmpty(sourceWord) || string.IsNullOrEmpty(targetWord))
            {
                return false;
            }

            var sourceCharCounts = sourceWord.GroupBy(c => c).ToDictionary(g => g.Key, g => g.Count());
            var targetCharCounts = targetWord.GroupBy(c => c).ToDictionary(g => g.Key, g => g.Count());

            foreach (var targetChar in targetCharCounts)
            {
                if (!sourceCharCounts.ContainsKey(targetChar.Key) || sourceCharCounts[targetChar.Key] < targetChar.Value)
                {
                    return false;
                }
            }

            return true;
        }
    }
}
