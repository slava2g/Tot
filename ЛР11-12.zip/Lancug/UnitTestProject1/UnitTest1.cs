﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace UnitTestProject1
{
    [TestClass]
    public class WordBuilderTests
    {
        private WordBuilder _wordBuilder;

        [TestInitialize]
        public void Setup()
        {
            _wordBuilder = new WordBuilder();
        }

        [TestMethod]
        public void CanFormWord_ShouldReturnTrue_WhenTargetWordCanBeFormed()
        {
            var sourceWord = "hello";
            var targetWord = "ole";

            var result = _wordBuilder.CanFormWord(sourceWord, targetWord);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void CanFormWord_ShouldReturnFalse_WhenTargetWordContainsMoreOfACharThanSourceWord()
        {
            var sourceWord = "hello";
            var targetWord = "helloo";

            var result = _wordBuilder.CanFormWord(sourceWord, targetWord);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CanFormWord_ShouldReturnFalse_WhenSourceWordIsEmpty()
        {
            var sourceWord = "";
            var targetWord = "hello";

            var result = _wordBuilder.CanFormWord(sourceWord, targetWord);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CanFormWord_ShouldReturnFalse_WhenTargetWordIsEmpty()
        {
            var sourceWord = "hello";
            var targetWord = "";

            var result = _wordBuilder.CanFormWord(sourceWord, targetWord);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CanFormWord_ShouldReturnTrue_WhenSourceAndTargetWordsAreIdentical()
        {
            var sourceWord = "hello";
            var targetWord = "hello";

            var result = _wordBuilder.CanFormWord(sourceWord, targetWord);

            Assert.IsTrue(result);
        }
    }
}