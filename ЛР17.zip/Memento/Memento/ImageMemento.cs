﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memento
{
    public class ImageMemento
    {
        public Bitmap ImageState { get; }

        public ImageMemento(Bitmap image)
        {
            ImageState = (Bitmap)image.Clone();
        }
    }
}
