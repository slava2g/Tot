﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memento
{
    public class Caretaker
    {
        private Stack<ImageMemento> _undoStack = new Stack<ImageMemento>();
        private Stack<ImageMemento> _redoStack = new Stack<ImageMemento>();

        public void SaveState(Bitmap image)
        {
            _undoStack.Push(new ImageMemento(image));
            _redoStack.Clear();
        }

        public Bitmap Undo()
        {
            if (_undoStack.Count > 1)
            {
                _redoStack.Push(_undoStack.Pop());
                return _undoStack.Peek().ImageState;
            }
            return null;
        }

        public Bitmap Redo()
        {
            if (_redoStack.Count > 0)
            {
                var redoState = _redoStack.Pop();
                _undoStack.Push(redoState);
                return redoState.ImageState;
            }
            return null;
        }
    }
}
