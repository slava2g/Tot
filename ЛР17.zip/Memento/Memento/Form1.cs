﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Memento
{
    public partial class Form1 : Form
    {
        private TrackBar trackBarSize;
        private Bitmap _canvas;
        private Graphics _graphics;
        private Caretaker _caretaker = new Caretaker();
        private bool _isDrawing = false;
        private Pen _pen = new Pen(Color.Black, 5);
        private Point _previousPoint;
        public Form1()
        {
            InitializeComponent();
            trackBarSize = new TrackBar();
            trackBarSize.Minimum = 1;
            trackBarSize.Maximum = 20;
            trackBarSize.Value = 5; 
            trackBarSize.Location = new Point(10, 10); 
            trackBarSize.Size = new Size(200, 45);
            trackBarSize.Scroll += trackBarSize_Scroll; 

            Controls.Add(trackBarSize);

            _canvas = new Bitmap(800, 600);
            _graphics = Graphics.FromImage(_canvas);
            _graphics.Clear(Color.White);
            pictureBox1.Image = _canvas;
            _caretaker.SaveState(_canvas);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            var previousImage = _caretaker.Undo();
            if (previousImage != null)
            {
                _canvas = previousImage;
                _graphics = Graphics.FromImage(_canvas);
                pictureBox1.Image = _canvas;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var nextImage = _caretaker.Redo();
            if (nextImage != null)
            {
                _canvas = nextImage;
                _graphics = Graphics.FromImage(_canvas);
                pictureBox1.Image = _canvas;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            _graphics.Clear(Color.White);
            pictureBox1.Refresh();
            _caretaker.SaveState(_canvas);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            using (ColorDialog dlg = new ColorDialog())
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _pen.Color = dlg.Color;
                }
            }
        }
        private void trackBarSize_Scroll(object sender, EventArgs e)
        {
            _pen.Width = trackBarSize.Value;
        }

        private void pictureBox1_MouseDown_1(object sender, MouseEventArgs e)
        {
            if (checkBox1.Checked)
            {
                _isDrawing = true;
                _previousPoint = e.Location;
            }
        }

        private void pictureBox1_MouseUp_1(object sender, MouseEventArgs e)
        {
            if (_isDrawing)
            {
                _caretaker.SaveState(_canvas);
                _isDrawing = false;
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (_isDrawing)
            {
                _graphics.DrawLine(_pen, _previousPoint, e.Location);
                _previousPoint = e.Location;
                pictureBox1.Invalidate(); // Оновлює зображення на PictureBox
            }
        }
    }
}
