﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediator
{
    public class PaymentComponent
    {
        protected IPaymentMediator mediator;

        public PaymentComponent(IPaymentMediator mediator)
        {
            this.mediator = mediator;
        }
    }
}

