﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mediator
{
    public class PaymentMediator : IPaymentMediator
    {
        private ComboBox comboBox1; 
        private ComboBox comboBox2;
        private TextBox textBox1;   
        private TextBox textBox2;   
        private Button button1;     

        public PaymentMediator(ComboBox comboBox1, ComboBox comboBox2, TextBox textBox1, TextBox textBox2, Button button1)
        {
            this.comboBox1 = comboBox1;
            this.comboBox2 = comboBox2;
            this.textBox1 = textBox1;
            this.textBox2 = textBox2;
            this.button1 = button1;

            this.button1.Click += (sender, e) => Notify(button1, "PayClicked");
        }

        public void Notify(object sender, string eventType)
        {
            if (eventType == "PayClicked")
            {
                string cardType = comboBox1.SelectedItem?.ToString();
                string paymentType = comboBox2.SelectedItem?.ToString();
                string amountText = textBox1.Text;

                if (string.IsNullOrEmpty(cardType) || string.IsNullOrEmpty(paymentType) || string.IsNullOrEmpty(amountText))
                {
                    textBox2.Text = "Будь ласка, заповніть усі поля!";
                    return;
                }

                if (!decimal.TryParse(amountText, out decimal amount) || amount <= 0)
                {
                    textBox2.Text = "Некоректна сума!";
                    return;
                }

                IPaymentService service = GetPaymentService(cardType);
                string result = service.ProcessPayment(amount, paymentType);
                textBox2.Text = result;
            }
        }

        private IPaymentService GetPaymentService(string cardType)
        {
            switch (cardType)
            {
                case "Visa":
                    return new VisaPaymentService();
                case "MasterCard":
                    return new MasterCardPaymentService();
                case "PayPal":
                    return new PayPalPaymentService();
                default:
                    return new DefaultPaymentService();
            }
        }
    }

}
