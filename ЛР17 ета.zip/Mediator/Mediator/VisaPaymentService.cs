﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediator
{
    public class VisaPaymentService : IPaymentService
    {
        public string ProcessPayment(decimal amount, string paymentType)
        {
            return $"Оплата {amount} грн через Visa ({paymentType}) успішна!";
        }
    }
}
