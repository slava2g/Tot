﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nagladach
{
    public class Recipient : IObserver
    {
        public string Name { get; private set; }
        private ListBox listBox;

        public Recipient(string name, ListBox listBox)
        {
            Name = name;
            this.listBox = listBox;
        }

        public void Update(string message)
        {
            listBox.Items.Add($"{Name} отримав повідомлення: {message}");
        }
    }
}
