﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nagladach
{
    public partial class Form1 : Form
    {
        private PostOffice postOffice;
        public Form1()
        {
            InitializeComponent();
            postOffice = new PostOffice();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Будь ласка, введіть ім'я гравця.");
                return;
            }

            Recipient recipient = new Recipient(textBox1.Text, listBox1);
            postOffice.AddObserver(recipient);

            listBox1.Items.Add(textBox1.Text);

            textBox1.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                MessageBox.Show("Будь ласка, виберіть отримувача.");
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Будь ласка, введіть, що ви хочете відправити.");
                return;
            }

            string recipientName = listBox1.SelectedItem.ToString();
            string message = textBox2.Text;

            postOffice.NotifyObservers($"Повідомлення для {recipientName}", message);

            textBox2.Clear();
        }
    }
}
