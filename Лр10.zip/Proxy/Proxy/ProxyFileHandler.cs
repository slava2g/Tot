﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy
{
    public class ProxyFileHandler : IFileHandler
    {
        private readonly RealFileHandler _realFileHandler;

        public ProxyFileHandler(RealFileHandler realFileHandler)
        {
            _realFileHandler = realFileHandler;
        }

        public string ReadFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("Файл не знайдено.");
            }
            return _realFileHandler.ReadFile(filePath);
        }

        public void WriteFile(string filePath, string content)
        {
            if (string.IsNullOrWhiteSpace(filePath))
            {
                throw new ArgumentException("Шлях до файлу не може бути порожнім.");
            }
            _realFileHandler.WriteFile(filePath, content);
        }
    }
}
