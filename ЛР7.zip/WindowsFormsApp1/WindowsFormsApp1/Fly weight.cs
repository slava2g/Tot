﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class LampParam
    {
        public int Size;   
        public Bitmap Picture; 
        public Color LightColor;  

        public LampParam(int size, string imagePath, Color lightColor)
        {
            Size = size;
            Picture = new Bitmap(imagePath);
            LightColor = lightColor;
        }
    }

    public class LampParamFactory
    {
        private static readonly Dictionary<string, LampParam> Params = new Dictionary<string, LampParam>();

        public static LampParam GetLampParam(string key, int size, string imagePath, Color lightColor)
        {
            if (!Params.ContainsKey(key))
            {
                Params[key] = new LampParam(size, imagePath, lightColor);
            }
            return Params[key];
        }
    }

    public class Lamp
    {
        public int X, Y;   
        public LampParam Param;  

        public Lamp(int x, int y, LampParam param)
        {
            X = x;
            Y = y;
            Param = param;
        }

        public override string ToString()
        {
            return $"Lamp at position: x = {X}, y = {Y}, size = {Param.Size}, color = {Param.LightColor}";
        }
    }
}