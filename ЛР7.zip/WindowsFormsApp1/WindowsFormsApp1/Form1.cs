﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
         
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            g = this.CreateGraphics();

            lampParams = new[]
            {
                LampParamFactory.GetLampParam("red", 30, @"C:\Users\ALEX\red_bulb.jpg", Color.Red),
                LampParamFactory.GetLampParam("green", 40, @"C:\Users\ALEX\green_bulb.jpg", Color.Green),
                LampParamFactory.GetLampParam("blue", 50, @"C:\Users\ALEX\blue_bulb.jpg", Color.Blue)
            };
        }

        Graphics g;
        Random random = new Random();
        LampParam[] lampParams;
        List<Lamp> garland = new List<Lamp>(); 

        private void timer1_Tick(object sender, EventArgs e)
        {

            g.Clear(this.BackColor);

            if (garland.Count < 50) 
            {
                LampParam randomParam = lampParams[random.Next(lampParams.Length)];
                int x = random.Next(10, this.ClientSize.Width - 50);
                int y = random.Next(50, this.ClientSize.Height - 50);
                garland.Add(new Lamp(x, y, randomParam));
            }


            foreach (var lamp in garland)
            {
                g.DrawImage(lamp.Param.Picture, new Rectangle(lamp.X, lamp.Y, lamp.Param.Size, lamp.Param.Size));

                using (SolidBrush brush = new SolidBrush(Color.FromArgb(50, lamp.Param.LightColor)))
                {
                    g.FillEllipse(brush, new Rectangle(lamp.X - 10, lamp.Y - 10, lamp.Param.Size + 20, lamp.Param.Size + 20));
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
